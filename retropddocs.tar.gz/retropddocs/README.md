makesensegraph.py produces a sense graph from aligned parallel data, as described in 

Ettinger et al. (2016). "Retrofitting Sense-Specific Word Vectors Using Parallel Text" Proceedings of NAACL-HLT 2016. 


The sense graph is in an output format intended for use with the retrofitting process introduced in

Jauhar et al. (2015). "Ontologically Grounded Multi-sense Representation Learning for Semantic Vector Space Models". Proceedings of NAACL-HLT 2015.



Usage details as follows:

Takes in three alignment files in the format of Berkeley Aligner (Liang et al. 2006, 'Alignment by Agreement') output files:
--> aligndoc: file with trained sentence position alignments (line format e.g. '1-1 2-3 5-4 6-6')
--> sentences docs: two files with all aligned sentences, one per language (lines must match with those in aligndoc)

Corresponding input arguments:
-i or --aligndoc : specify path to aligndoc (file with trained sentence position alignments)
-f or --first : specify path to sentences doc for language in *first* position in alignments (e.g. '*1*-1 *2*-3 *5*-4 *6*-6')
-s or --second : specify path to sentences doc for language in *second* position in alignments (e.g. '1-*1* 2-*3* 5-*4* 6-*6*')

Other critical input arguments:
-p or --pivotlang : specify which language is serving as sense annotation for the other ('fst' for first-position, 'sec' for second-position, as in -f and -s above)
-o or --outfile : specify output file. 
-h or --statthresh : specify G-test statistic threshold below which to filter out translations

Optionally lemmatize parallel corpus when getting translations (assumes a lookup table in format of XTAG English morphological database):
-l or --lemmatize : set to 1 if lemmatizing, 0 if not (default is 0)
-a or --lemA : if lemmatizing language in *first* alignment position (as described above), specify path to lookup table for that language
-b or --lemB : if lemmatizing language in *second* alignment position (as described above), specify path to lookup table for that language

Optionally run G-test statistic values through logistic function before converting to weights
-g or --logistic : set to 1 if using logistic, 0 if not (default is 0)
"-t", "--top" : if using logistic, specify maximum value of curve (default is 1)
"-k", "--k" : if using logistic, specify steepness of curve (default is 1)
"-m", "--mid" : if using logistic, specify x-value of sigmoid midpoint
