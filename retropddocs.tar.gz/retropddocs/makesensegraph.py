#!/usr/bin/python
# -*- coding: utf8 -*-

"""
Copyright (C) 2016 Allyson Ettinger <aetting@umd.edu>

Takes in three alignment files in the format of Berkeley Aligner (Liang et al. 2006, 'Alignment by Agreement') output files:
--> aligndoc: file with trained sentence position alignments (line format e.g. '1-1 2-3 5-4 6-6')
--> sentences docs: two files with all aligned sentences, one per language (lines must match with those in aligndoc)

Corresponding input arguments:
-i or --aligndoc : specify path to aligndoc (file with trained sentence position alignments)
-f or --first : specify path to sentences doc for language in *first* position in alignments (e.g. '*1*-1 *2*-3 *5*-4 *6*-6')
-s or --second : specify path to sentences doc for language in *second* position in alignments (e.g. '1-*1* 2-*3* 5-*4* 6-*6*')

Other critical input arguments:
-p or --pivotlang : specify which language is serving as sense annotation for the other ('fst' for first-position, 'sec' for second-position, as in -f and -s above)
-o or --outfile : specify output file. 
-h or --statthresh : specify G-test statistic threshold below which to filter out translations

Optionally lemmatize parallel corpus when getting translations (assumes a lookup table in format of XTAG English morphological database):
-l or --lemmatize : set to 1 if lemmatizing, 0 if not (default is 0)
-a or --lemA : if lemmatizing language in *first* alignment position (as described above), specify path to lookup table for that language
-b or --lemB : if lemmatizing language in *second* alignment position (as described above), specify path to lookup table for that language

Optionally run G-test statistic values through logistic function before converting to weights
-g or --logistic : set to 1 if using logistic, 0 if not (default is 0)
"-t", "--top" : if using logistic, specify maximum value of curve (default is 1)
"-k", "--k" : if using logistic, specify steepness of curve (default is 1)
"-m", "--mid" : if using logistic, specify x-value of sigmoid midpoint
"""

import math,sys,re,os,getopt,numpy
from sys import stdout, stderr


#process command line arguments
def readCommandLineInput(argv):
    try:
        try:
            #specify the possible option switches
            opts, _ = getopt.getopt(sys.argv[1:], "i:f:s:p:o:h:t:k:m:l:a:b:g:", ["aligndoc=", "first=","second=","pivotlang=", "outfile=",
                                                              "statthresh=","top=", "k=", "mid=", "lemmatize=","lemA=","lemB=","logistic="])
        except: print 'INPUT INCORRECT'
        
        alignpath = None
        firstpath = None
        secondpath = None
        pivotlang = None
        
        outfile = None
        
        statThresh = None
        
        lemmatize = 0
        lemtableA = None
        lemtableB = None
        
        logistic = 0
        top=1
        k = 1
        mid = None

        # option processing
        for option, value in opts:
            if option in ("-i", "--aligndoc"):
                alignpath = value
            elif option in ("-f", "--first"):
                firstpath = value
            elif option in ("-s", "--second"):
                secondpath = value
            elif option in ("-p", "--pivotlang"):
                pivotlang = value
            elif option in ("-o", "--outfile"):
                outfile = value
            elif option in ("-s", "--stat"):
                stat = value
            elif option in ("-h", "--statthresh"):
                statThresh = value
            elif option in ("-c", "--counthresh"):
                countThresh = value
            elif option in ("-t", "--top"):
                top = value
            elif option in ("-k", "--k"):
                k = value
            elif option in ("-m", "--mid"):
                mid = value
            elif option in ("-l", "--lemmatize"):
                lemmatize = bool(int(value))
            elif option in ("-a", "--lemA"):
                lemtableA = value
            elif option in ("-b", "--lemB"):
                lemtableB = value
            elif option in ("-g", "--logistic"):
                logistic = bool(int(value))
            else:
                stderr.write("Doesn't match any option: %s,%s"%(option,value))        
        
        return (alignpath,firstpath,secondpath,pivotlang,outfile,statThresh,logistic,top,k,mid,lemmatize,lemtableA,lemtableB)
    except: 
        stderr.write("Error reading command line arguments.\n")
        

def cleanAlignments(alignpath,firstpath,secondpath,pivotlang,lemmatize,lemtableA,lemtableB):
    
    #load lemma dict if lemmatizing
    if lemmatize:
        if lemtableA:
            lemmaDictA = readLemmatizer(lemtableA)
        if lemtableB:
            lemmaDictB = readLemmatizer(lemtableB)
    
    stdout.write('GETTING ALIGNMENT COUNTS\n')
    
    #read alignment documents
    alignDoc = open(alignpath)
    secAligndoc = open(secondpath)
    fstAligndoc = open(firstpath)
    alignLines = alignDoc.read().split('\n')
    secAlignLines = secAligndoc.read().split('\n') 
    fstAlignLines = fstAligndoc.read().split('\n') 
    alignDoc.close()
    secAligndoc.close()
    fstAligndoc.close()
         
    translations = {}
    counts = {}
    num_alignments = 0
    training_length = len(alignLines)
    
    #loop through lines of parallel data
    for i in range(len(alignLines)):
        if i % 5000 == 0:
            stdout.write('.')
            stdout.flush()
        alignLine = alignLines[i].split()
        fstLine = fstAlignLines[i].split()
        secLine = secAlignLines[i].split()

        
        #get aligned words based on aligned sentence positions in alignDoc
        for j in range(len(alignLine)):
            fstPos = int(alignLine[j].split('-')[0])
            secPos = int(alignLine[j].split('-')[1])
            if fstPos >= len(fstLine) or secPos >= len(secLine): 
                break 
            num_alignments += 1	
            fstWord = fstLine[fstPos]
            secWord = secLine[secPos]
            
            #substitute # and % characters to avoid interference with separators in retrofit procedure
            secWord = re.sub('[#|%]','-',secWord)
            fstWord = re.sub('[#|%]','-',fstWord)
            
            #if lemmatizing, look up lemmatized forms in lemma dict
            if lemmatize:
                if lemtableA:
                    if fstWord in lemmaDictA: 
                        fstWord = lemmaDictA[fstWord]
                if lemtableB:
                    if secWord in lemmaDictB: 
                        secWord = lemmaDictB[secWord]
            
            #update single word counts dict
            if not counts.has_key(secWord): counts[secWord] = 0
            if not counts.has_key(fstWord): counts[fstWord] = 0
            counts[secWord] += 1
            counts[fstWord] += 1
            
            #set pivotword and corresponding aligned word
            if pivotlang == 'sec': 
                pivotWord = secWord
                pairWord = fstWord
            else:
                pivotWord = fstWord
                pairWord = secWord
            
            #update translation counts dict    
            if not translations.has_key(pivotWord): translations[pivotWord] = {}
            if not translations[pivotWord].has_key(pairWord): translations[pivotWord][pairWord] = 0
            translations[pivotWord][pairWord] += 1
    print ''
    
    return [translations,counts,num_alignments,training_length]
    
def filterGraph(translations,counts,num_alignments,statThresh,top,k,mid,logistic):
    #filter alignments by G-test statistic
    senseWgt = 1.
    num_alignments = float(num_alignments)
    statThresh = float(statThresh)
    if logistic:
        top = float(top)
        k = float(k)
        mid = float(mid)
    graphDict = {}
    for pivotword,alignw,gVal in getG(translations,counts,num_alignments,statThresh):
        if logistic: w = logisticFunction(gVal,top,k,mid) 
        else: 
            w = senseWgt          
        if not pivotword in graphDict: graphDict[pivotword] = {}
        graphDict[pivotword][alignw] = w
    
    return graphDict

        
def getG(translations,counts,num_alignments,gThresh):
    gThresh = float(gThresh)
    stdout.write('GETTING G-TEST STATISTICS\n')
    for pivotword,alignwordsdict in translations.items():
        for alignw, t in alignwordsdict.items():
            cP = float(counts[pivotword])
            notP = num_alignments - cP
            cA = float(counts[alignw])
            notA = num_alignments - cA
            
            joint = float(translations[pivotword][alignw])
            p_notA = cP - joint
            a_notP = cA - joint
            neither = num_alignments - (joint + p_notA + a_notP)
            
            joint_Exp = (cP/num_alignments) * cA
            p_notA_Exp = (cP/num_alignments) * notA
            a_notP_Exp = (notP/num_alignments) * cA
            neither_Exp = (notP/num_alignments) * notA
            
            O = [joint,p_notA,a_notP,neither]
            E = [joint_Exp,p_notA_Exp,a_notP_Exp,neither_Exp]
            
            gSum = 0
            for i in range(len(O)):
                if O[i] == 0  or E[i] == 0: continue
                term = O[i]*math.log(O[i]/E[i])
                gSum += term
            gVal = 2*gSum
            
            if gVal < gThresh: continue
            
            yield (pivotword,alignw,gVal)
    
    
def printGraph(graphDict,outfile):
    senseagWgt = 1.
    graphName = os.path.join(outfile)
    with open(outfile,'w') as ontolDoc:
        for pivotword,alignwordsdict in graphDict.items():
            for alignw, alignwWgt in alignwordsdict.items(): 
                otherWords = [a for a in alignwordsdict.items() if a[0] != alignw]
                ontolDoc.write(alignw + '%' + pivotword + '#' + str(senseagWgt)+ ' ')
                for word,alignWgt in otherWords:
                    symmetWgt = numpy.mean([alignWgt,alignwWgt])
                    printWgt = symmetWgt
                    ontolDoc.write(word + '%' + pivotword + '#' + str(printWgt) + ' ')
                ontolDoc.write('\n')
                
                
def logisticFunction(x,top,k,mid):
    y = top/(1+math.exp(-k*(x-mid)))
    return y

def readLemmatizer(lemtable):
    ##read lemmatization lookup table in format of XTAG morphological database lookup table
    d = {}
    f = open(lemtable)
    for line in f:
        if line.startswith(';;;'): continue
        list = line.split()
        d[list[0]] = list[1]
    return d
    
    
if __name__ == "__main__":
    (alignpath,firstpath,secondpath,pivotlang,outfile,statThresh,logistic,top,k,mid,lemmatize,lemtableA,lemtableB) = readCommandLineInput(sys.argv) 
    if not (alignpath and firstpath and secondpath and pivotlang and outfile and statThresh):
        stderr.write("Missing critical input argument! (one of three alignment docs, output filename, specification of sense-annotation language, or G-test threshold)\n")
        sys.exit()
    if lemmatize and not (lemtableA or lemtableB):
        stderr.write("If lemmatizing, need path to lemmatization lookup table for relevant language(s)!\n")
        sys.exit()
    if logistic and not (top and k and mid):
        stderr.write("If using logistic function, need to specify function parameters! (at least midpoint x-value)\n")
        sys.exit()
    [translations,counts,num_alignments,training_length] = cleanAlignments(alignpath,firstpath,secondpath,pivotlang,lemmatize,lemtableA,lemtableB)
    graphDict = filterGraph(translations,counts,num_alignments,statThresh,top,k,mid,logistic)
    printGraph(graphDict,outfile)